#!/bin/bash
set -u

printf '=== EPV production preflight ===\n'
if [ -r /etc/redhat-release ]; then
    printf 'OS: %s\n' "$(cat /etc/redhat-release)"
else
    printf 'WARNING: /etc/redhat-release not found; target is expected to be RHEL 7/8/9/10.\n'
fi

printf 'Kernel: %s\n' "$(uname -r)"
printf 'Arch: %s\n' "$(uname -m)"
printf 'glibc: %s\n' "$(getconf GNU_LIBC_VERSION 2>/dev/null || echo unknown)"
printf 'OpenSSL: %s\n' "$(openssl version 2>/dev/null || echo MISSING)"
printf 'GCC: %s\n' "$(gcc --version 2>/dev/null | head -n 1 || echo MISSING)"

missing=0
for pkg in gcc openssl-devel sqlite-devel jansson-devel; do
    if command -v rpm >/dev/null 2>&1; then
        if rpm -q "$pkg" >/dev/null 2>&1; then
            printf 'OK package: %s\n' "$pkg"
        else
            printf 'MISSING package: %s\n' "$pkg"
            missing=1
        fi
    fi
done

for cmd in gcc openssl sha256sum; do
    if command -v "$cmd" >/dev/null 2>&1; then
        printf 'OK command: %s -> %s\n' "$cmd" "$(command -v "$cmd")"
    else
        printf 'MISSING command: %s\n' "$cmd"
        missing=1
    fi
done

if command -v systemd-analyze >/dev/null 2>&1; then
    printf 'systemd: %s\n' "$(systemd --version 2>/dev/null | head -n 1 || true)"
fi

if [ "$missing" -ne 0 ]; then
    printf '\nPreflight FAILED: install missing development packages before building.\n' >&2
    printf 'RHEL: yum/dnf install gcc openssl-devel sqlite-devel jansson-devel\n' >&2
    exit 1
fi
printf '\nPreflight PASS\n'
