#!/bin/bash
set -u

mode="${1:-shadow}"
case "$mode" in
    shadow) db=/ws/shadow.db ;;
    snapshot) db=/ws/snapshot.db ;;
    *) echo "Usage: $0 shadow|snapshot" >&2; exit 2 ;;
esac

rc=0
check_file() {
    f=$1
    if [ -r "$f" ]; then
        printf 'OK readable: %s\n' "$f"
    else
        printf 'FAIL unreadable/missing: %s\n' "$f" >&2
        rc=1
    fi
}

check_file "$db"
check_file /opt/epm_certs/server.crt
check_file /opt/epm_certs/server.key
check_file /opt/epm_certs/ca.crt
check_file /etc/epv/connector.role

if id epvconnector >/dev/null 2>&1; then
    for f in "$db" /opt/epm_certs/server.crt /opt/epm_certs/server.key /opt/epm_certs/ca.crt /etc/epv/connector.role; do
        if runuser -u epvconnector -- test -r "$f"; then
            printf 'OK epvconnector can read: %s\n' "$f"
        else
            printf 'FAIL epvconnector cannot read: %s\n' "$f" >&2
            rc=1
        fi
    done
else
    printf 'FAIL service account epvconnector does not exist\n' >&2
    rc=1
fi

exit "$rc"
