#!/bin/bash
set -Eeuo pipefail
IFS=$'\n\t'

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/build/bin"
mkdir -p "$OUT"

"$ROOT/tools/preflight_rhel.sh"

printf '\n=== Build EPV client v2.3.3 ===\n'
(
    cd "$ROOT/client"
    ./epv_api_cli_v2.3.3_rhel7_build.sh \
        epv_api_cli_v2.3.3_rhel7.c \
        epv_api_cli_v2.3.3_rhel7
)
cp -p "$ROOT/client/epv_api_cli_v2.3.3_rhel7" "$OUT/"

printf '\n=== Build shadow connector v2.3.2 ===\n'
(
    cd "$ROOT/connectors/shadow"
    ./api_connector_shadow_v2.3.2_build.sh \
        api_connector_shadow_v2.3.2.c \
        api_connector_shadow_v2.3.2
)
cp -p "$ROOT/connectors/shadow/api_connector_shadow_v2.3.2" "$OUT/"

printf '\n=== Build snapshot connector v2.3.2 ===\n'
(
    cd "$ROOT/connectors/snapshot"
    ./api_connector_snapshot_v2.3.2_build.sh \
        api_connector_snapshot_v2.3.2.c \
        api_connector_snapshot_v2.3.2
)
cp -p "$ROOT/connectors/snapshot/api_connector_snapshot_v2.3.2" "$OUT/"

printf '\n=== Built binaries ===\n'
ls -lh "$OUT"
printf '\nIMPORTANT: deploy binaries built on the same RHEL major version (or an older compatible build root).\n'
