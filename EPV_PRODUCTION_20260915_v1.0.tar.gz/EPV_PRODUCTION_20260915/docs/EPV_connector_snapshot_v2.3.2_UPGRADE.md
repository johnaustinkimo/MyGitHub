# EPV Snapshot Connector v2.3.2 Upgrade

`api_connector_snapshot_v2.3.2.c` is a compatibility/hardening upgrade of the original snapshot v2.3.1 connector.

## Preserved database model

This release intentionally continues using:

- `/ws/snapshot.db`
- `users`
- `access`
- `records`
- `SHA256(pass_salt + supplied_password)` login verification
- `snapshot.lkg.db`

It does **not** use the new shadow schema (`gen_file`, `epv_file`, `epa_file`, `epb_file`).

## Ported from the shadow v2.3.2 line

- RHEL7/8/9/10 adaptive build support
- OpenSSL 1.0.2 through OpenSSL 3.x compatibility
- TLS 1.2 minimum on the OpenSSL 1.0.2 path
- portable certificate expiry inspection
- full sensitive crypto/password diagnostics when `--debug` is explicitly enabled
- dynamic shutdown version string

## Additional snapshot-specific RHEL7 fix

The snapshot login verifier in v2.3.1 used `EVP_MD_CTX_new/free()`, which is unavailable on the standard RHEL7 OpenSSL 1.0.2 stack. v2.3.2 computes the same SHA-256 verifier using `EVP_Digest()` instead. The authentication result is unchanged.

## Build

```bash
chmod 755 api_connector_snapshot_v2.3.2_build.sh
./api_connector_snapshot_v2.3.2_build.sh
```

Dependencies:

```bash
yum install -y gcc openssl-devel sqlite-devel jansson-devel
```

For RHEL8/9/10, `dnf` may be used instead.

## Production example

```bash
./api_connector_snapshot_v2.3.2 \
  6666 strict \
  --workers 8 \
  --db /ws/snapshot.db \
  --runtime-dir /run/epv-api-connector-snapshot-v2.3.2 \
  --handshake-timeout 5 \
  --io-timeout 10 \
  --cert-warn-days 30 \
  --snapshot-warn-age 172800 \
  --token-binding compat \
  --role active
```

Do not add `--debug` to the normal production service because this release intentionally prints plaintext/encrypted credentials and token contents in debug mode.
