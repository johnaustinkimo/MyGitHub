# EPV API client v2.3.3 - multi-instance/config isolation fix

## Problem
Two client binaries executed by the same Unix uid could share:

- `/tmp/epv_api_active_server_<uid>.cache`
- `/tmp/epv_api_token_origin_<uid>.cache`

The cache key did not include the executable or `--server-file`.  In addition,
when an external server file contained valid entries, the client still appended
the compiled-in `builtin_servers[]`.  This meant separately configured clients
could share stale state or cross-connect into the same fallback cluster.

The cache locks also used blocking `flock()`.  Although the normal critical
section is short, a stuck process/filesystem condition could make a second CLI
wait without a bounded cache-lock deadline.

## v2.3.3 changes

1. Cache namespace = SHA-256(executable real path + server-file canonical path + port), first 16 hex chars.
2. Active cache examples:
   - `/tmp/epv_api_active_server_<uid>_<namespace>.cache`
3. Token-origin cache examples:
   - `/tmp/epv_api_token_origin_<uid>_<namespace>.cache`
4. Advisory cache locks are bounded to 250 ms. Cache is optional; on timeout the CLI bypasses it and continues.
5. A non-empty external server file is authoritative. `builtin_servers[]` is used only when the configured file is missing/empty.
6. v2.3.2 fast priority recovery probe remains unchanged: one HEALTH attempt with the short priority probe timeout.
7. Wire protocol remains compatible with snapshot/shadow connector v2.3.2.

## Recommended deployment

Primary client:

```bash
/aprun/shell/epv_api \
  --server-file /opt/epm_certs/epv_servers.ini \
  --priority-recheck 30 \
  --priority-probe-timeout 1
```

Second client:

```bash
/aprun/shell/epv_api_second \
  --server-file /opt/epm_certs/epv_servers_second.ini \
  --priority-recheck 30 \
  --priority-probe-timeout 1
```

Old v2.3.1/v2.3.2 shared cache files can be removed after all old client processes stop:

```bash
rm -f /tmp/epv_api_active_server_$(id -u).cache
rm -f /tmp/epv_api_token_origin_$(id -u).cache
```

Do not wildcard-delete the new names while v2.3.3 clients are running.
