PMS v2.1 backend query fix / Frontend v2.0.3
================================================

Fixes
-----
1. ADMIN "授權帳密" pmsQuery returning no rows.
2. "密碼資料" pms2Query showing:
       Binary file (standard input) matches
3. Decryption errors are now explicit:
       ERROR|PMS_DECRYPT_FAILED
       ERROR|PMS_PLAINTEXT_INVALID
4. pms2Query no longer builds/evals a dynamic egrep command.
5. Frontend rejects malformed/binary-warning rows instead of displaying them.
6. Keeps the WebSocket diagnostic improvements from v2.0.2.

Files
-----
PMS_v2.0.3.html
pmsGP_v2.1.sh
pmsGP_web_v2.1.sh
wsmanager2_v2.1.sh

Recommended deployment
----------------------
1. Back up current files:
   cp -p /ws/pmsGP.sh /ws/pmsGP.sh.before_v2.1
   cp -p /ws/wsmanager2.sh /ws/wsmanager2.sh.before_v2.1

2. Install versioned files:
   cp -p pmsGP_v2.1.sh /ws/pmsGP_v2.1.sh
   cp -p pmsGP_web_v2.1.sh /ws/pmsGP_web_v2.1.sh
   cp -p wsmanager2_v2.1.sh /ws/wsmanager2_v2.1.sh
   chmod 750 /ws/pmsGP_v2.1.sh /ws/pmsGP_web_v2.1.sh /ws/wsmanager2_v2.1.sh

3. Syntax check:
   bash -n /ws/pmsGP_v2.1.sh
   bash -n /ws/pmsGP_web_v2.1.sh
   bash -n /ws/wsmanager2_v2.1.sh

4. Point websocketd to /ws/wsmanager2_v2.1.sh and restart its service/process.

5. Replace the frontend with PMS_v2.0.3.html and hard refresh (Ctrl+F5).

Manual backend verification
---------------------------
Use a valid, non-expired ADMIN login:

/ws/pmsGP_web_v2.1.sh ADMIN pmsQuery  <ADMIN_ID> '<PASSWORD>' @   1 1 1
/ws/pmsGP_web_v2.1.sh ADMIN pms2Query <ADMIN_ID> '<PASSWORD>' all 1 1 1

Expected pmsQuery row:
1|op|<password>|2026-09-20_04:45:41

Expected pms2Query row:
1|root|<password>|<prefix>|<suffix>|2026-09-20_04:45:41

Validate encrypted PMS data directly
------------------------------------
seed=$(cut -d'|' -f1 /ws/geu_file)
openssl enc -aes-256-cbc -d -pbkdf2 -a -salt \
  -pass "$seed" -in /ws/pms_file | head

The decrypted content must be text in this format:
account|password|timestamp

Notes
-----
- Do not replace /ws/pms_file or /ws/geu_file during this deployment.
- pmsGP_v2.1.sh keeps the existing password rotation logic; only the pmsQuery and
  pms2Query read/query paths were hardened.
